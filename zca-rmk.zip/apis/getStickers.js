import { ZaloApiError } from "../Errors/ZaloApiError.js";
import { apiFactory } from "../utils.js";
export const getStickersFactory = apiFactory()((api, ctx, utils) => {
    const serviceURL = utils.makeURL(`${api.zpwServiceMap.sticker}/api/message/sticker`);
    /**
     * Get stickers by keyword
     *
     * @param keyword Keyword to search for
     * @returns Sticker IDs
     *
     * @throws {ZaloApiError}
     */
    return async function getStickers(keyword) {
        if (!keyword)
            throw new ZaloApiError("Missing keyword");
        const params = {
            keyword: keyword,
            gif: 1,
            guggy: 0,
            imei: ctx.imei,
        };
        const encryptedParams = utils.encodeAES(JSON.stringify(params));
        if (!encryptedParams)
            throw new ZaloApiError("Failed to encrypt message");
        const finalServiceUrl = new URL(serviceURL);
        finalServiceUrl.pathname = finalServiceUrl.pathname + "/suggest/stickers";
        const response = await utils.request(utils.makeURL(finalServiceUrl.toString(), {
            params: encryptedParams,
        }));
        return utils.resolve(response, (result) => {
            const suggestions = result.data;
            const stickerIds = [];
            const gifIds = [];
            const guggyIds = [];
            if (suggestions.sugg_sticker)
                suggestions.sugg_sticker.forEach((sticker) => stickerIds.push(sticker.sticker_id));
            if (suggestions.sugg_gif)
                suggestions.sugg_gif.forEach((gif) => gifIds.push(gif.sticker_id ?? gif.id));
            if (suggestions.sugg_guggy)
                suggestions.sugg_guggy.forEach((guggy) => guggyIds.push(guggy.sticker_id ?? guggy.id));
            return { stickerIds, gifIds, guggyIds };
        });
    };
});
